import Root from "./aspect-ratio.svelte";

export { Root, Root as AspectRatio };
